#include<fstream>
#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;

int main()
{
    char a[50];
    fstream f;
    f.open("input_f.dat",ios::in);
    f.get(a,50);

    fstream g;
    g.open("output_f.dat",ios::out);

    for(int i=0;i<strlen(a);i++)
    {if(isdigit(a[i]))
    {g<<a[i];
    if(isalpha(a[i+1])) g<<endl;}}
    f.close();
    g.close();
}
